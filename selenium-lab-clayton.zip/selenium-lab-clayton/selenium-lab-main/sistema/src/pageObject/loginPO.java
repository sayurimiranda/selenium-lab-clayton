package pageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPO extends BasePO {

    @FindBy(id = "email")
    private WebElement inputEmail;

    @FindBy(id = "senha")
    private WebElement inputSenha;

    @FindBy(id = "botao-login")
    private WebElement botaoLogin;

    public LoginPO(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    public void preencherEmail(String email) {
        inputEmail.sendKeys(email);
    }

    public void preencherSenha(String senha) {
        inputSenha.sendKeys(senha);
    }

    public void clicarEmLogin() {
        botaoLogin.click();
    }

}
