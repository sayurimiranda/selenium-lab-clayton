package tests;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import pageObject.LoginPO;

public class LoginTest {

    @Test
    public void naoDeveLogarNoSistemaComEmailESenhaVazios() {
        // Cria uma instância da PO de login
        LoginPO loginPO = new LoginPO(driver);

        // Preenche os campos de email e senha com valores vazios
        loginPO.preencherEmail("");
        loginPO.preencherSenha("");

        // Tenta fazer login
        loginPO.clicarEmLogin();

        // Verifica se a mensagem de erro foi exibida
        Assertions.assertEquals("E-mail ou senha inválidos", loginPO.obterMensagemDeErro());
    }

    @Test
    public void naoDeveLogarNoSistemaComEmailIncorretoESenhaVazia() {
        // Cria uma instância da PO de login
        LoginPO loginPO = new LoginPO(driver);

        // Preenche o campo de email com um valor incorreto
        loginPO.preencherEmail("email.invalido@example.com");
        loginPO.preencherSenha("");

        // Tenta fazer login
        loginPO.clicarEmLogin();

        // Verifica se a mensagem de erro foi exibida
        Assertions.assertEquals("E-mail ou senha inválidos", loginPO.obterMensagemDeErro());
    }
}
