# Importa as bibliotecas necessárias
import time

from selenium import webdriver
from selenium.webdriver.common.keys import Keys


# Define a função de teste
def test_cadastrar_produto_sem_nome():
    # Abre o navegador e acessa a página de cadastro de produto
    driver = webdriver.Chrome()
    driver.get("http://localhost:8080/produtos/cadastrar")

    # Preenche o campo descrição
    descricao_produto = "Uma descrição para o meu produto"
    driver.find_element_by_id("descricao").send_keys(descricao_produto)

    # Preenche o campo preço
    preco_produto = 100.00
    driver.find_element_by_id("preco").send_keys(str(preco_produto))

    # Seleciona a categoria "Eletrônicos"
    categoria = "Eletrônicos"
    driver.find_element_by_id("categoria").find_element_by_xpath(
        f"//option[@value='{categoria}']"
    ).click()

    # Clica no botão "Cadastrar"
    driver.find_element_by_id("cadastrar").click()

    # Verifica se o produto não foi cadastrado
    mensagem_erro = driver.find_element_by_id("mensagem-erro").text
    assert mensagem_erro == "O nome do produto é obrigatório!"

    # Fecha o navegador
    driver.close()
