# Importa as bibliotecas necessárias
import time

from selenium import webdriver
from selenium.webdriver.common.keys import Keys


# Define a função de teste
def test_cadastrar_produto_sucesso():
    # Abre o navegador e acessa a página de cadastro de produto
    driver = webdriver.Chrome()
    driver.get("http://localhost:8080/produtos/cadastrar")

    # Preenche o campo nome
    nome_produto = "Meu produto"
    driver.find_element_by_id("nome").send_keys(nome_produto)

    # Preenche o campo descrição
    descricao_produto = "Uma descrição para o meu produto"
    driver.find_element_by_id("descricao").send_keys(descricao_produto)

    # Preenche o campo preço
    preco_produto = 100.00
    driver.find_element_by_id("preco").send_keys(str(preco_produto))

    # Seleciona a categoria "Eletrônicos"
    categoria = "Eletrônicos"
    driver.find_element_by_id("categoria").find_element_by_xpath(
        f"//option[@value='{categoria}']"
    ).click()

    # Clica no botão "Cadastrar"
    driver.find_element_by_id("cadastrar").click()

    # Verifica se o produto foi cadastrado com sucesso
    mensagem_sucesso = driver.find_element_by_id("mensagem-sucesso").text
    assert mensagem_sucesso == "Produto cadastrado com sucesso!"

    # Fecha o navegador
    driver.close()
