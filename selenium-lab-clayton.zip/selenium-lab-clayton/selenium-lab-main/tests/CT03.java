# Importa as bibliotecas necessárias
import time

from selenium import webdriver
from selenium.webdriver.common.keys import Keys


# Define a função de teste
def test_cadastrar_produto_sem_descricao():
    # Abre o navegador e acessa a página de cadastro de produto
    driver = webdriver.Chrome()
    driver.get("http://localhost:8080/prod
